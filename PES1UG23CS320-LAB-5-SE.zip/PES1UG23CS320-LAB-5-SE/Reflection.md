# Reflection – Lab 5: Static Code Analysis

## 1. Which issues were the easiest to fix, and which were the hardest?

The easiest issues to fix were the **formatting and style warnings** reported by Flake8, such as
trailing whitespace, missing final newline, and long lines exceeding 79 characters.  
These only required simple code cleanup and line wrapping.

The hardest issues were **replacing the bare `except:` block** and **configuring logging properly**
without causing duplicate log messages. These required more careful adjustments to maintain the
program’s flow and clarity while satisfying Pylint and Bandit’s strict checks.

---

## 2. Did the static analysis tools report any false positives?

Yes. Pylint flagged the use of a **global variable (`stock_data`)** as a potential design issue.
However, in this context, the global variable is acceptable since the program is a small,
self-contained inventory system. Therefore, this warning was not a real problem but a
reasonable exception for this lab’s scope.

---

## 3. How would you integrate static analysis tools into your workflow?

I would integrate **Pylint, Bandit, and Flake8** into a **Continuous Integration (CI) pipeline**
(e.g., GitHub Actions or Jenkins).  
Each commit or pull request can automatically run these tools to check for code quality, security,
and style compliance before merging.  
During local development, I would also use pre-commit hooks to automatically run Flake8 and Pylint
so that any issues are caught early.

---

## 4. What tangible improvements did you observe in the code?

After applying all the fixes, the code became **cleaner, safer, and easier to maintain**:

- The dangerous `eval()` call was removed (security improvement).
- Input validation prevents invalid types from being added to inventory.
- Bare `except:` was replaced with specific exceptions for better error handling.
- Proper logging was added for consistent and traceable operations.
- Flake8 formatting fixes improved readability and PEP8 compliance.

Overall, the program now passes **Pylint (10.00/10)**, **Flake8 (0 warnings)**, and **Bandit (0 issues)**,  
demonstrating improved code quality, maintainability, and robustness.
