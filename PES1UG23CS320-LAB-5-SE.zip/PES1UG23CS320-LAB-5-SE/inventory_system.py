"""
Inventory Management System
A simple tool to manage stock items with add, remove, and report features.
"""
import json
import logging
from datetime import datetime

# FIX: Added proper logging configuration (previously missing)
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(message)s")
logger = logging.getLogger(__name__)

# Global variable
stock_data = {}


def add_item(item=None, qty=0, logs=None):
    """
    Add an item to the inventory.

    Args:
        item: Name of the item (must be string)
        qty: Quantity to add (must be positive integer)
        logs: Optional list to store log messages
    """
    # FIX: Changed default mutable argument logs=[] to logs=None
    if logs is None:
        logs = []

    # FIX: Added validation for item name and quantity
    if not item or not isinstance(item, str):
        logger.warning("Invalid item name provided")
        return

    if not isinstance(qty, int) or qty < 0:
        logger.warning("Invalid quantity provided: %s", qty)
        return

    stock_data[item] = stock_data.get(item, 0) + qty
    log_msg = f"{datetime.now()}: Added {qty} of {item}"
    logs.append(log_msg)
    logger.info(log_msg)


def remove_item(item, qty):
    """
    Remove an item from the inventory.

    Args:
        item: Name of the item
        qty: Quantity to remove
    """
    try:
        # FIX: Added validation before accessing dictionary
        if item not in stock_data:
            logger.warning("Item '%s' not found in inventory", item)
            return

        stock_data[item] -= qty
        if stock_data[item] <= 0:
            del stock_data[item]
            # FIX: Improved logging message for clarity
            logger.info(
                "Item '%s' removed from inventory (stock depleted)", item
            )
    # FIX: Replaced bare 'except:' with specific exceptions
    except KeyError as e:
        logger.error("KeyError while removing item: %s", e)
    except TypeError as e:
        logger.error("TypeError while removing item: %s", e)


def get_qty(item):
    """
    Get the quantity of an item in stock.

    Args:
        item: Name of the item

    Returns:
        Quantity of the item, or 0 if not found
    """
    return stock_data.get(item, 0)


def load_data(file="inventory.json"):
    """
    Load inventory data from a JSON file.

    Args:
        file: Path to the JSON file
    """
    global stock_data  # pylint: disable=global-statement
    try:
        with open(file, "r", encoding="utf-8") as f:
            stock_data = json.load(f)
        logger.info("Data loaded from %s", file)
    except FileNotFoundError:
        # FIX: Added FileNotFoundError handling
        logger.warning(
            "File %s not found, starting with empty inventory", file
        )
        stock_data = {}
    except json.JSONDecodeError as e:
        logger.error("Error decoding JSON from %s: %s", file, e)


def save_data(file="inventory.json"):
    """
    Save inventory data to a JSON file.

    Args:
        file: Path to the JSON file
    """
    try:
        with open(file, "w", encoding="utf-8") as f:
            json.dump(stock_data, f, indent=2)
        logger.info("Data saved to %s", file)
    # FIX: Added IOError handling for file write failures
    except IOError as e:
        logger.error("Error saving data to %s: %s", file, e)


def print_data():
    """Print a report of all items in inventory."""
    print("\n=== Inventory Report ===")
    if not stock_data:
        print("No items in inventory")
    else:
        for item, quantity in stock_data.items():
            print(f"{item} -> {quantity}")
    print("========================\n")


def check_low_items(threshold=5):
    """
    Check for items with low stock.

    Args:
        threshold: Minimum quantity threshold

    Returns:
        List of items below threshold
    """
    result = []
    for item, quantity in stock_data.items():
        if quantity < threshold:
            result.append(item)
    return result


def main():
    """Main function to demonstrate inventory system functionality."""
    # FIX: Reconfigured logging for main execution context
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    # Test the system
    add_item("apple", 10)
    add_item("banana", 5)
    add_item(123, "ten")  # FIX: Invalid input triggers validation

    remove_item("apple", 3)
    remove_item("orange", 1)

    print(f"Apple stock: {get_qty('apple')}")
    print(f"Low items: {check_low_items()}")

    save_data()
    load_data()
    print_data()

    # FIX: Removed insecure eval() call
    logger.info("System demonstration completed")


if __name__ == "__main__":
    main()
